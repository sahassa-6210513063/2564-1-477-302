let openDiaryRight = document.querySelector('.h1');
let diaryWrapper = document.querySelector(".diary-wrapper");

openDiaryRight.addEventListener('click',function() {
    diaryWrapper.classList.toggle('open');
});
